
from setuptools import setup

setup (
    name="primer_paquete",
    version="1.0",
    description="Carga de datos de clientes y sus respectivas compras utilizando conceptos de la primer pre_entrega y de las clases de POO",
    author="Marcelo Luna",
    author_email="marcelo_luna2003@hotmail.com",
    packages=["package"]
)