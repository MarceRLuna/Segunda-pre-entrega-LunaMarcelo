# Segunda pre-Entrega

Programa realizado para el Curso de Python - comisión 54145 de la plataforma de aprendizaje online CoderHouse.
La aplicación permite cargar datos de un cliente y los productos comprados. Los clientes y productos posteriormente permiten ser visualizados.

## Autor

- Marcelo Luna

## Tecnologías utilizadas

- Python 3.11.0

## Funcionalidades

- Cargar lista de clientes.
- Agregar datos a un cliente determinado.
- Agergar una lista de compras realizadas por el cliente cargado.
- Ver listados los clientes y productos comprados.


## Licencia

Este proyecto puede ser usado por quién pueda aprovecharlo, para tener guías básicas de cómo abordar los conceptos que en este se intentan transmitir.