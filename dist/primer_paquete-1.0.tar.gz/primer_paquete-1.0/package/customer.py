

class Customer:
    
    def __init__(self, nombre,apellido, mail, telefono):
        self.nombre = nombre
        self.apellido = apellido
        self.mail = mail
        self.telefono = telefono

    def __str__(self):
        return f'El nombre completo del cliente es {self.nombre} {self.apellido}, su dirección de correo es {self.mail} y su nro. de contacto es {self.telefono}'



